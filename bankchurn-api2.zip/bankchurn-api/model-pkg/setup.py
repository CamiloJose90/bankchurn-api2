from setuptools import setup, find_packages

setup(
    name="modelo-abandono",
    version="0.0.2",
    packages=find_packages(where="model_abandono-0.0.2"),
    package_dir={"": "model_abandono-0.0.2"},
)